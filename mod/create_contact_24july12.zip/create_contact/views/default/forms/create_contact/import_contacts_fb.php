<?php
	/**
	 * Created By Rijo Joy
	 */
include(elgg_get_plugins_path()  . "create_contact/vendors/facebookauth/examples/with_js_sdk.php"); 
?>